import torch
import torch.nn as nn 
import torch.backends.cudnn as cudnn
from  torch.autograd import Variable



from PIL import Image

import cv2 
from skimage import io 
import numpy as np 
import models.craft.craft_utils as craft_utils
import models.craft.imgproc  as imgproc
import models.craft.file_utils  as file_utils
import json 
import zipfile




def main():

    print("Libraries loaded properly")


if __name__ == "__main__":

    main()

