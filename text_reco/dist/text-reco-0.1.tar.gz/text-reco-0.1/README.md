# Text recognition tool

End to end text recognition. 

technologies:


- CRAFT 
- CRNN


Start 03072019

Focus on fast processing, frontend, compatibility. 



To do:

everythin
